"""SQLite persistence for snapshots and application settings."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from app.services.provider import Account


class Database:
    """Owns the local SQLite database and its small persistence operations."""

    def __init__(self, path: Path):
        """Store the database path without opening a long-lived connection."""
        self.path = path

    def connect(self) -> sqlite3.Connection:
        """Open a row-aware SQLite connection."""
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def initialize(self) -> None:
        """Create required tables when the application starts."""
        with self.connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    profile TEXT NOT NULL,
                    list_type TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    source TEXT NOT NULL,
                    complete INTEGER NOT NULL,
                    expected_count INTEGER,
                    returned_count INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS snapshot_accounts (
                    snapshot_id INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    display_name TEXT NOT NULL,
                    account_type TEXT NOT NULL,
                    visibility TEXT NOT NULL,
                    verified INTEGER NOT NULL,
                    PRIMARY KEY (snapshot_id, username),
                    FOREIGN KEY (snapshot_id) REFERENCES snapshots(id)
                );
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                """
            )

    def save_snapshot(
        self,
        profile: str,
        list_type: str,
        accounts: list[Account],
        source: str,
        complete: bool,
        expected_count: int | None,
    ) -> int:
        """Persist a snapshot and all returned account rows atomically."""
        created_at = datetime.now(timezone.utc).isoformat()
        with self.connect() as connection:
            cursor = connection.execute(
                """INSERT INTO snapshots
                (profile, list_type, created_at, source, complete, expected_count, returned_count)
                VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    profile,
                    list_type,
                    created_at,
                    source,
                    int(complete),
                    expected_count,
                    len(accounts),
                ),
            )
            snapshot_id = int(cursor.lastrowid)
            connection.executemany(
                """INSERT INTO snapshot_accounts
                (snapshot_id, username, display_name, account_type, visibility, verified)
                VALUES (?, ?, ?, ?, ?, ?)""",
                [
                    (
                        snapshot_id,
                        account.username,
                        account.display_name,
                        account.account_type,
                        account.visibility,
                        int(account.verified),
                    )
                    for account in accounts
                ],
            )
            return snapshot_id

    def list_snapshots(self) -> list[sqlite3.Row]:
        """Return snapshots newest first for the history screen."""
        with self.connect() as connection:
            return connection.execute(
                "SELECT * FROM snapshots ORDER BY id DESC"
            ).fetchall()

    def get_snapshot_usernames(self, snapshot_id: int) -> list[str]:
        """Return usernames stored in a particular snapshot."""
        with self.connect() as connection:
            rows = connection.execute(
                "SELECT username FROM snapshot_accounts WHERE snapshot_id = ? ORDER BY username",
                (snapshot_id,),
            ).fetchall()
        return [row["username"] for row in rows]

    def save_setting(self, key: str, value: object) -> None:
        """Store a JSON-serialised setting."""
        with self.connect() as connection:
            connection.execute(
                "INSERT INTO settings(key, value) VALUES(?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, json.dumps(value)),
            )

    def get_setting(self, key: str, default: object = None) -> object:
        """Read a setting, returning the provided default when absent."""
        with self.connect() as connection:
            row = connection.execute(
                "SELECT value FROM settings WHERE key = ?", (key,)
            ).fetchone()
        return json.loads(row["value"]) if row else default
