"""Desktop user-interface package."""
